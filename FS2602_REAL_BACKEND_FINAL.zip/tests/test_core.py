import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import backend.app as appmod
from backend.app import connect, init_schema, ensure_seed, FeaturesIn, create_decision, verify_chain, eval_condition

def isolated_db(tmp_path):
    appmod.DB_PATH = tmp_path / 'test.db'
    con=connect(); init_schema(con); ensure_seed(con)
    con.execute("INSERT INTO applicants(applicant_id,name,created_at,updated_at) VALUES ('T1','Test',?,?)", (appmod.iso_now(),appmod.iso_now()))
    con.commit(); return con

def test_snapshot_immutable(tmp_path):
    con=isolated_db(tmp_path)
    out=create_decision('T1',FeaturesIn(rent_months_ontime=10,utility_months_ontime=10,telecom_months_ontime=10,income_proxy=.7,tenure_months=30))
    sid=out['snapshot_id']
    import sqlite3
    try:
        con.execute('UPDATE decision_snapshots SET score=0 WHERE id=?',(sid,))
        assert False
    except sqlite3.DatabaseError: pass
    try:
        con.execute('DELETE FROM decision_snapshots WHERE id=?',(sid,))
        assert False
    except sqlite3.DatabaseError: pass
    con.close()

def test_audit_tamper_detection(tmp_path):
    con=isolated_db(tmp_path); create_decision('T1',FeaturesIn(rent_months_ontime=10,utility_months_ontime=10,telecom_months_ontime=10,income_proxy=.7,tenure_months=30)); create_decision('T1',FeaturesIn(rent_months_ontime=9,utility_months_ontime=9,telecom_months_ontime=9,income_proxy=.6,tenure_months=24)); create_decision('T1',FeaturesIn(rent_months_ontime=8,utility_months_ontime=8,telecom_months_ontime=8,income_proxy=.5,tenure_months=18)); con.close()
    r=appmod.tamper_scratch('edit'); assert r['valid_after_tamper'] is False
    r=appmod.tamper_scratch('delete'); assert r['valid_after_tamper'] is False
    r=appmod.tamper_scratch('reorder'); assert r['valid_after_tamper'] is False

def test_fail_closed(tmp_path):
    con=isolated_db(tmp_path); con.execute('INSERT OR REPLACE INTO feature_bans(feature_name,banned_at,reason) VALUES (?,?,?)',('income_proxy',appmod.iso_now(),'test')); con.commit(); con.close()
    out=create_decision('T1',FeaturesIn(rent_months_ontime=10,utility_months_ontime=10,telecom_months_ontime=10,income_proxy=.7,tenure_months=30))
    assert out['decision']=='no_decision'
    con=connect(); assert con.execute('SELECT COUNT(*) FROM decision_snapshots').fetchone()[0]==0; assert con.execute("SELECT COUNT(*) FROM audit_log WHERE entry_type='failed_attempt'").fetchone()[0]==1; con.close()

def test_rule_grammar():
    assert eval_condition({'field':'age','operator':'gte','value':18},{'age':25}) is True
    assert eval_condition({'all':[{'field':'age','operator':'gte','value':18},{'field':'kyc_status','operator':'eq','value':'verified'}]},{'age':25,'kyc_status':'verified'}) is True
