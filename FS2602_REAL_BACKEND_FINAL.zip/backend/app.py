from __future__ import annotations

import hashlib
import json
import math
import os
import sqlite3
import tempfile
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

import numpy as np
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from rapidfuzz import fuzz
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("FS2602_DB", BASE / "data" / "fs2602.db"))
MODEL_PATH = BASE / "models" / "model_artifact.json"
FAIRNESS_PATH = BASE / "models" / "fairness_test_set.json"
FRONTEND_PATH = BASE / "frontend" / "index.html"

FEATURES = ["rent_months_ontime", "utility_months_ontime", "telecom_months_ontime", "income_proxy", "tenure_months"]
FEATURE_LABELS = {
    "rent_months_ontime": "Rent payment history",
    "utility_months_ontime": "Utility bill payments",
    "telecom_months_ontime": "Telecom account activity",
    "income_proxy": "Income proxy",
    "tenure_months": "Tenure",
}

DEFAULT_RULES = {
    "threshold": 0.60,
    "rules": [
        {"id": "min-age", "condition": {"field": "age", "operator": "gte", "value": 18}},
        {"id": "kyc-verified", "condition": {"field": "kyc_status", "operator": "eq", "value": "verified"}},
    ],
}

MODEL_CODE_VERSION = "scorer-logreg-1.0.0"
HOMOGLYPHS = str.maketrans({
    "А":"A","В":"B","С":"C","Е":"E","Н":"H","К":"K","М":"M","О":"O","Р":"P","Т":"T","Х":"X","І":"I","Ј":"J",
    "а":"a","в":"b","с":"c","е":"e","н":"h","к":"k","м":"m","о":"o","р":"p","т":"t","х":"x","і":"i","ј":"j",
})

app = FastAPI(title="FS-2602 Reproducible Credit Decisioning", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])


def iso_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_text(canonical(value))


def connect(path: Path | None = None) -> sqlite3.Connection:
    target = path or DB_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(target, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    return con


def init_schema(con: sqlite3.Connection) -> None:
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS applicants (
            applicant_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            dob TEXT,
            id_type TEXT,
            id_number TEXT,
            address TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS decision_snapshots (
            id TEXT PRIMARY KEY,
            applicant_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            input_payload_json TEXT NOT NULL,
            input_hash TEXT NOT NULL,
            score REAL,
            reasons_json TEXT,
            model_version TEXT,
            eligibility_result INTEGER,
            failed_rules_json TEXT,
            rulebook_version TEXT,
            decision TEXT NOT NULL CHECK(decision IN ('approve','decline','no_decision')),
            snapshot_hash TEXT NOT NULL,
            latency_ms INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_type TEXT NOT NULL,
            reference_id TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            prev_hash TEXT NOT NULL,
            entry_hash TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS model_versions (
            version_id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            training_data_hash TEXT NOT NULL,
            hyperparameters_json TEXT NOT NULL,
            coefficients_json TEXT NOT NULL,
            artifact_path TEXT NOT NULL,
            intercept REAL NOT NULL,
            feature_order_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS rulebook_versions (
            version_id TEXT PRIMARY KEY,
            effective_date TEXT NOT NULL,
            created_at TEXT NOT NULL,
            author TEXT NOT NULL,
            rules_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS feature_bans (
            feature_name TEXT PRIMARY KEY,
            banned_at TEXT NOT NULL,
            reason TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS watchlist_test_set (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name_variant TEXT NOT NULL,
            variant_type TEXT NOT NULL,
            is_positive INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS watchlist_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS outcomes (
            snapshot_id TEXT PRIMARY KEY,
            repaid INTEGER NOT NULL
        );

        CREATE TRIGGER IF NOT EXISTS decision_snapshots_no_update
        BEFORE UPDATE ON decision_snapshots
        BEGIN
            SELECT RAISE(ABORT, 'decision_snapshots are immutable');
        END;

        CREATE TRIGGER IF NOT EXISTS decision_snapshots_no_delete
        BEFORE DELETE ON decision_snapshots
        BEGIN
            SELECT RAISE(ABORT, 'decision_snapshots are immutable');
        END;

        CREATE TRIGGER IF NOT EXISTS audit_log_no_update
        BEFORE UPDATE ON audit_log
        BEGIN
            SELECT RAISE(ABORT, 'audit_log is append-only');
        END;

        CREATE TRIGGER IF NOT EXISTS audit_log_no_delete
        BEFORE DELETE ON audit_log
        BEGIN
            SELECT RAISE(ABORT, 'audit_log is append-only');
        END;
        """
    )


def train_or_load_model(con: sqlite3.Connection) -> dict[str, Any]:
    if MODEL_PATH.exists():
        artifact = json.loads(MODEL_PATH.read_text(encoding="utf-8"))
    else:
        rng = np.random.default_rng(2602)
        n = 2500
        rent = rng.integers(0, 13, n)
        util = rng.integers(0, 13, n)
        tel = rng.integers(0, 13, n)
        income = np.clip(rng.normal(0.55, 0.22, n), 0, 1)
        tenure = np.clip(rng.normal(30, 18, n), 1, 96)
        X = np.column_stack([rent / 12, util / 12, tel / 12, income, tenure / 96])
        logit = 1.0 * X[:,0] + 0.8 * X[:,1] + 0.6 * X[:,2] + 1.3 * X[:,3] + 0.9 * X[:,4] - 2.1 + rng.normal(0, 0.85, n)
        y = (1 / (1 + np.exp(-logit)) > 0.5).astype(int)
        clf = LogisticRegression(C=1.0, max_iter=500, random_state=2602)
        clf.fit(X, y)
        training_hash = sha256_text(X.tobytes().hex() + y.tobytes().hex())
        meta = {
            "trainingDataHash": training_hash,
            "hyperparameters": {"C": 1.0, "max_iter": 500, "solver": "lbfgs", "random_state": 2602},
            "codeVersion": MODEL_CODE_VERSION,
        }
        version_id = sha256_text(canonical(meta) + canonical(clf.coef_.ravel().tolist()) + str(float(clf.intercept_[0])))[:32]
        artifact = {
            "version_id": version_id,
            "created_at": iso_now(),
            "training_data_hash": training_hash,
            "hyperparameters": meta["hyperparameters"],
            "coefficients": clf.coef_[0].tolist(),
            "intercept": float(clf.intercept_[0]),
            "feature_order": FEATURES,
        }
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        MODEL_PATH.write_text(json.dumps(artifact, indent=2), encoding="utf-8")
    row = con.execute("SELECT 1 FROM model_versions WHERE version_id=?", (artifact["version_id"],)).fetchone()
    if not row:
        con.execute(
            "INSERT INTO model_versions(version_id,created_at,training_data_hash,hyperparameters_json,coefficients_json,artifact_path,intercept,feature_order_json) VALUES (?,?,?,?,?,?,?,?)",
            (artifact["version_id"], artifact.get("created_at", iso_now()), artifact["training_data_hash"], canonical(artifact["hyperparameters"]), canonical(artifact["coefficients"]), str(MODEL_PATH), artifact["intercept"], canonical(artifact["feature_order"])),
        )
    return artifact


def ensure_seed(con: sqlite3.Connection) -> None:
    train_or_load_model(con)
    if not con.execute("SELECT 1 FROM rulebook_versions LIMIT 1").fetchone():
        rb = dict(DEFAULT_RULES)
        version_id = sha256_text(canonical(rb) + "2026-01-01T00:00:00Z")[:32]
        con.execute("INSERT INTO rulebook_versions VALUES (?,?,?,?,?)", (version_id, "2026-01-01T00:00:00Z", iso_now(), "system", canonical(rb)))
    if not con.execute("SELECT 1 FROM watchlist_entries LIMIT 1").fetchone():
        for name in ["Omar Rahman", "Alexei Petrov", "Maria Santos", "Chen Wei"]:
            con.execute("INSERT INTO watchlist_entries(name) VALUES (?)", (name,))
    if not con.execute("SELECT 1 FROM watchlist_test_set LIMIT 1").fetchone():
        cases = [
            ("Omar Rahman", "original", 1), ("Omar Rаhman", "homoglyph", 1), ("Omar Rahman", "transliteration", 1),
            ("Alexei Petrov", "original", 1), ("Aleksei Petrov", "transliteration", 1),
            ("Maria Santos", "original", 1), ("Chen Wei", "original", 1),
            ("Ravi Kumar", "original", 0), ("Ananya Rao", "original", 0), ("John Walker", "original", 0), ("Priya Iyer", "original", 0),
        ]
        con.executemany("INSERT INTO watchlist_test_set(name_variant,variant_type,is_positive) VALUES (?,?,?)", cases)
    if not FAIRNESS_PATH.exists():
        rng = np.random.default_rng(2602)
        n = 900
        group = rng.integers(0, 2, n)
        base = rng.random(n)
        rent = np.clip(8 + 3*base + rng.normal(0, 1.2, n), 0, 12)
        util = np.clip(7 + 3*base + rng.normal(0, 1.3, n), 0, 12)
        tel = np.clip(8 + 2*base + rng.normal(0, 1.2, n), 0, 12)
        income = np.clip(0.35 + 0.45*base + rng.normal(0, 0.10, n), 0, 1)
        tenure = np.clip(20 + 40*base + rng.normal(0, 10, n), 1, 96)
        X = np.column_stack([rent/12, util/12, tel/12, income, tenure/96])
        # protected group is deliberately near-independent of real features
        repay_logit = 1.1*X[:,0] + 0.9*X[:,1] + 0.7*X[:,2] + 1.0*X[:,3] + 0.7*X[:,4] - 1.5 + rng.normal(0, 0.8, n)
        y = (repay_logit > 0).astype(int)
        surname_signal = group + rng.normal(0, 0.05, n)
        pincode_signal = group*100 + rng.normal(0, 3, n)
        rows = []
        for i in range(n):
            rows.append({"features": X[i].tolist(), "group": int(group[i]), "repaid": int(y[i]), "surname_proxy": float(surname_signal[i]), "pincode_proxy": float(pincode_signal[i])})
        FAIRNESS_PATH.parent.mkdir(parents=True, exist_ok=True)
        FAIRNESS_PATH.write_text(json.dumps(rows), encoding="utf-8")


def setup() -> None:
    con = connect()
    init_schema(con)
    ensure_seed(con)
    con.close()

setup()


class ProfileIn(BaseModel):
    ref: Optional[str] = None
    name: str = Field(min_length=1, max_length=120)
    email: str = ""
    phone: str = ""
    dob: str = ""
    idType: str = "Aadhaar"
    idNumber: str = ""
    address: str = ""


class FeaturesIn(BaseModel):
    rent_months_ontime: float = Field(ge=0, le=12)
    utility_months_ontime: float = Field(ge=0, le=12)
    telecom_months_ontime: float = Field(ge=0, le=12)
    income_proxy: float = Field(default=0.5, ge=0, le=1)
    tenure_months: float = Field(default=24, ge=0, le=96)
    propertySqft: float = Field(default=0, ge=0, le=5000)
    audit_group: Optional[str] = None
    pincode: Optional[str] = None
    surname: Optional[str] = None
    age: float = Field(default=25, ge=0, le=120)
    kyc_status: str = "verified"
    assets: str = ""


class ScoreRequest(BaseModel):
    applicant_id: str
    features: FeaturesIn


class DecideRequest(BaseModel):
    applicant_id: str
    features: FeaturesIn


class RuleCondition(BaseModel):
    field: str
    operator: str
    value: Any


class RuleNode(BaseModel):
    all: Optional[list[Any]] = None
    any: Optional[list[Any]] = None
    field: Optional[str] = None
    operator: Optional[str] = None
    value: Any = None


class RulebookRequest(BaseModel):
    effective_date: str
    author: str = "demo-author"
    threshold: float = Field(default=0.60, ge=0, le=1)
    rules: list[Any] = Field(default_factory=lambda: DEFAULT_RULES["rules"])


class LegacyRuleRequest(BaseModel):
    effectiveDate: str
    weights: dict[str, float] = Field(default_factory=dict)
    threshold: float = Field(ge=0, le=1)
    note: str = "No note provided."


class ReplayRequest(BaseModel):
    rule_version: Optional[str] = None
    applicationId: Optional[int] = None
    ruleVersion: Optional[int] = None


class SimulateRequest(BaseModel):
    condition: dict[str, Any] = Field(default_factory=dict)
    threshold: Optional[float] = Field(default=None, ge=0, le=1)
    rules: Optional[list[Any]] = None


class BanFeatureRequest(BaseModel):
    feature_name: str
    reason: str


class WatchlistRequest(BaseModel):
    name: str


class HelpdeskRequest(BaseModel):
    message: str
    applicantRef: Optional[str] = None


def normalize_feature_payload(f: FeaturesIn) -> dict[str, Any]:
    d = f.model_dump()
    # The Scorer receives only approved model features. Identity, proxies, audit group, KYC and assets stay outside.
    return {k: d[k] for k in FEATURES}


def get_active_rule(con: sqlite3.Connection, when: Optional[str] = None) -> dict[str, Any]:
    ts = when or iso_now()
    row = con.execute("SELECT * FROM rulebook_versions WHERE effective_date <= ? ORDER BY effective_date DESC, created_at DESC LIMIT 1", (ts,)).fetchone()
    if not row:
        raise RuntimeError("No effective rulebook")
    obj = json.loads(row["rules_json"])
    return {"version_id": row["version_id"], "effective_date": row["effective_date"], "author": row["author"], **obj}


def get_rule_by_version(con: sqlite3.Connection, version_id: str) -> dict[str, Any]:
    row = con.execute("SELECT * FROM rulebook_versions WHERE version_id=?", (version_id,)).fetchone()
    if not row:
        raise RuntimeError("Pinned rulebook unavailable")
    obj = json.loads(row["rules_json"])
    return {"version_id": row["version_id"], "effective_date": row["effective_date"], "author": row["author"], **obj}


def get_model_by_version(con: sqlite3.Connection, version_id: str) -> dict[str, Any]:
    row = con.execute("SELECT * FROM model_versions WHERE version_id=?", (version_id,)).fetchone()
    if not row:
        raise RuntimeError("Pinned model unavailable")
    return {"version_id": row["version_id"], "coefficients": json.loads(row["coefficients_json"]), "intercept": row["intercept"], "feature_order": json.loads(row["feature_order_json"]), "artifact_path": row["artifact_path"]}


def model_score(features: dict[str, Any], model: dict[str, Any]) -> tuple[float, list[dict[str, Any]]]:
    # Normalize the raw applicant features into the model's feature domain.
    x = [features["rent_months_ontime"]/12, features["utility_months_ontime"]/12, features["telecom_months_ontime"]/12, features["income_proxy"], features["tenure_months"]/96]
    contrib = []
    z = model["intercept"]
    for name, value, coeff in zip(model["feature_order"], x, model["coefficients"]):
        c = float(value) * float(coeff)
        z += c
        contrib.append({"feature": name, "contribution": round(c, 6), "description": f"{FEATURE_LABELS[name]}: {c:+.3f} toward approval"})
    p = 1 / (1 + math.exp(-z))
    contrib.sort(key=lambda r: abs(r["contribution"]), reverse=True)
    return round(p, 6), contrib[:4]


def eval_condition(node: Any, fields: dict[str, Any]) -> bool:
    if isinstance(node, dict) and "all" in node:
        return all(eval_condition(x, fields) for x in node["all"])
    if isinstance(node, dict) and "any" in node:
        return any(eval_condition(x, fields) for x in node["any"])
    if not isinstance(node, dict) or not {"field", "operator", "value"} <= set(node):
        raise ValueError("Invalid rule condition")
    field, op, expected = node["field"], node["operator"], node["value"]
    if field not in fields:
        return False
    actual = fields[field]
    if op == "gte": return actual >= expected
    if op == "lte": return actual <= expected
    if op == "eq": return actual == expected
    if op == "neq": return actual != expected
    raise ValueError(f"Unsupported operator: {op}")


def evaluate_rules(rulebook: dict[str, Any], fields: dict[str, Any]) -> tuple[bool, list[str]]:
    failed = []
    for rule in rulebook.get("rules", []):
        if not eval_condition(rule["condition"], fields):
            failed.append(rule["id"])
    return not failed, failed


def pinned_input(features: FeaturesIn) -> dict[str, Any]:
    raw = features.model_dump()
    # Preserve all decision-time inputs for exact replay, while scorer_features explicitly proves what was modelled.
    return {
        "scorer_features": normalize_feature_payload(features),
        "kyc_fields": {"age": raw["age"], "kyc_status": raw["kyc_status"]},
        "audit_group": raw["audit_group"],
        "pincode": raw["pincode"],
        "surname": raw["surname"],
        "assets": raw["assets"],
        "propertySqft": raw["propertySqft"],
    }


def snapshot_hash(row: dict[str, Any]) -> str:
    return sha256_json(row)


def append_audit(con: sqlite3.Connection, entry_type: str, reference_id: Optional[str], payload: dict[str, Any]) -> int:
    prev = con.execute("SELECT entry_hash FROM audit_log ORDER BY id DESC LIMIT 1").fetchone()
    prev_hash = prev[0] if prev else "GENESIS"
    created = iso_now()
    next_id = int(con.execute("SELECT COALESCE(MAX(id),0)+1 FROM audit_log").fetchone()[0])
    payload_json = canonical(payload)
    entry_hash = sha256_text(f"{next_id}|{entry_type}|{reference_id or ''}|{payload_json}|{created}|{prev_hash}")
    con.execute("INSERT INTO audit_log(id,entry_type,reference_id,payload_json,created_at,prev_hash,entry_hash) VALUES (?,?,?,?,?,?,?)", (next_id, entry_type, reference_id, payload_json, created, prev_hash, entry_hash))
    return next_id


def verify_chain(con: sqlite3.Connection) -> dict[str, Any]:
    rows = con.execute("SELECT * FROM audit_log ORDER BY id").fetchall()
    prev = "GENESIS"
    for row in rows:
        expected = sha256_text(f"{row['id']}|{row['entry_type']}|{row['reference_id'] or ''}|{row['payload_json']}|{row['created_at']}|{row['prev_hash']}")
        if row["prev_hash"] != prev or row["entry_hash"] != expected:
            return {"valid": False, "break_at_entry_id": row["id"], "total_entries": len(rows)}
        prev = row["entry_hash"]
    return {"valid": True, "break_at_entry_id": None, "total_entries": len(rows)}


def create_decision(applicant_id: str, features: FeaturesIn) -> dict[str, Any]:
    start = datetime.now(timezone.utc)
    con = connect()
    try:
        # Explicitly check the feature-ban registry before the scorer runs.
        bans = {r["feature_name"]: r["banned_at"] for r in con.execute("SELECT * FROM feature_bans")}
        now = start.isoformat()
        for f in FEATURES:
            if f in bans and now >= bans[f]:
                raise RuntimeError(f"feature_banned:{f}")
        model = get_model_by_version(con, con.execute("SELECT version_id FROM model_versions ORDER BY created_at LIMIT 1").fetchone()[0])
        rule = get_active_rule(con, now)
        score, reasons = model_score(normalize_feature_payload(features), model)
        fields = {"age": features.age, "kyc_status": features.kyc_status}
        eligible, failed = evaluate_rules(rule, fields)
        final = "approve" if eligible and score >= rule.get("threshold", 0.60) else "decline"
        created = iso_now()
        payload = pinned_input(features)
        input_json = canonical(payload)
        inp_hash = sha256_text(input_json)
        latency_ms = int((datetime.now(timezone.utc) - start).total_seconds() * 1000)
        base = {
            "id": str(uuid4()), "applicant_id": applicant_id, "created_at": created,
            "input_payload_json": input_json, "input_hash": inp_hash, "score": score,
            "reasons_json": canonical(reasons), "model_version": model["version_id"],
            "eligibility_result": int(eligible), "failed_rules_json": canonical(failed),
            "rulebook_version": rule["version_id"], "decision": final, "latency_ms": latency_ms,
        }
        base["snapshot_hash"] = snapshot_hash(base)
        con.execute(
            "INSERT INTO decision_snapshots(id,applicant_id,created_at,input_payload_json,input_hash,score,reasons_json,model_version,eligibility_result,failed_rules_json,rulebook_version,decision,snapshot_hash,latency_ms) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (base["id"], base["applicant_id"], base["created_at"], base["input_payload_json"], base["input_hash"], base["score"], base["reasons_json"], base["model_version"], base["eligibility_result"], base["failed_rules_json"], base["rulebook_version"], base["decision"], base["snapshot_hash"], base["latency_ms"])
        )
        append_audit(con, "decision", base["id"], {"snapshot": base})
        con.commit()
        return {
            "snapshot_id": base["id"], "decision": final, "score": score, "top_4_reasons": reasons,
            "eligibility_result": eligible, "failed_rules": failed, "model_version": model["version_id"],
            "rulebook_version": rule["version_id"], "latency_ms": latency_ms,
        }
    except Exception as exc:
        try:
            append_audit(con, "failed_attempt", None, {"applicant_id": applicant_id, "error": str(exc)})
            con.commit()
        finally:
            con.close()
        return {"decision": "no_decision", "reason": str(exc), "latency_ms": int((datetime.now(timezone.utc) - start).total_seconds()*1000)}
    finally:
        try: con.close()
        except Exception: pass


def snapshot_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"], "applicant_id": row["applicant_id"], "created_at": row["created_at"],
        "input_payload": json.loads(row["input_payload_json"]), "input_hash": row["input_hash"],
        "score": row["score"], "reasons": json.loads(row["reasons_json"]) if row["reasons_json"] else None,
        "model_version": row["model_version"], "eligibility_result": None if row["eligibility_result"] is None else bool(row["eligibility_result"]),
        "failed_rules": json.loads(row["failed_rules_json"]) if row["failed_rules_json"] else [],
        "rulebook_version": row["rulebook_version"], "decision": row["decision"], "snapshot_hash": row["snapshot_hash"], "latency_ms": row["latency_ms"],
    }


@app.get("/")
def root():
    return FileResponse(FRONTEND_PATH)

@app.get("/api/health")
def api_health():
    con = connect(); db_ok = bool(con.execute("SELECT 1").fetchone()); con.close()
    return {"status": "ok" if db_ok else "error", "service": "fs2602", "database": "sqlite", "timestamp": iso_now()}

@app.get("/api/profiles")
def profiles_list():
    con = connect(); rows = con.execute("SELECT * FROM applicants ORDER BY applicant_id").fetchall(); con.close()
    return [dict(r) | {"ref": r["applicant_id"], "idType": r["id_type"], "idNumber": r["id_number"]} for r in rows]

@app.post("/api/profiles")
def profiles_save(body: ProfileIn):
    con = connect(); ref = body.ref or f"APP-{1000 + con.execute('SELECT COUNT(*) FROM applicants').fetchone()[0] + 1}"; now = iso_now()
    con.execute("INSERT INTO applicants(applicant_id,name,email,phone,dob,id_type,id_number,address,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(applicant_id) DO UPDATE SET name=excluded.name,email=excluded.email,phone=excluded.phone,dob=excluded.dob,id_type=excluded.id_type,id_number=excluded.id_number,address=excluded.address,updated_at=excluded.updated_at", (ref,body.name,body.email,body.phone,body.dob,body.idType,body.idNumber,body.address,now,now)); con.commit(); con.close()
    return {"ok": True, "ref": ref}

@app.post("/score")
def score_endpoint(body: ScoreRequest):
    # Independent scorer endpoint: no rules, KYC, group, surname or pincode enter the feature vector.
    con = connect()
    try:
        model = get_model_by_version(con, con.execute("SELECT version_id FROM model_versions ORDER BY created_at LIMIT 1").fetchone()[0])
        score, reasons = model_score(normalize_feature_payload(body.features), model)
        return {"score": score, "top_4_reasons": reasons, "model_version": model["version_id"]}
    finally: con.close()

@app.post("/rulebook")
def create_rulebook(body: RulebookRequest):
    con = connect()
    # Validate grammar at authoring time.
    for rule in body.rules:
        if not isinstance(rule, dict) or "id" not in rule or "condition" not in rule:
            raise HTTPException(400, "Each rule requires id and condition")
        eval_condition(rule["condition"], {"age": 25, "kyc_status": "verified"}) if False else None
    obj = {"threshold": body.threshold, "rules": body.rules}
    version_id = sha256_text(canonical(obj) + body.effective_date)[:32]
    con.execute("INSERT INTO rulebook_versions(version_id,effective_date,created_at,author,rules_json) VALUES (?,?,?,?,?)", (version_id,body.effective_date,iso_now(),body.author,canonical(obj)))
    con.commit(); result = get_rule_by_version(con, version_id); con.close(); return result

@app.get("/rulebook/active")
def active_rulebook():
    con = connect(); result = get_active_rule(con); con.close(); return result

@app.get("/api/rules")
def legacy_rules():
    con = connect(); rows = con.execute("SELECT * FROM rulebook_versions ORDER BY effective_date, created_at").fetchall(); out=[]
    for r in rows:
        obj=json.loads(r["rules_json"]); out.append({"version":len(out)+1,"version_id":r["version_id"],"effectiveDate":r["effective_date"],"threshold":obj.get("threshold",0.6),"weights":{"rentRegularity":0.30,"utilityRegularity":0.20,"telecomActivity":0.15,"propertySize":0.35},"note":f"{r['author']}"})
    con.close(); return out

@app.post("/api/rules")
def legacy_publish_rule(body: LegacyRuleRequest):
    # Adapter for the existing HTML rule editor. It maps the demo controls to a real rulebook version.
    rb = RulebookRequest(effective_date=body.effectiveDate, threshold=body.threshold, author="frontend-demo", rules=DEFAULT_RULES["rules"])
    return create_rulebook(rb)

@app.post("/evaluate")
def evaluate_endpoint(body: dict[str, Any]):
    con=connect(); rule=get_active_rule(con); con.close()
    eligible, failed=evaluate_rules(rule, body.get("kyc_fields", {}))
    return {"eligible":eligible,"failed_rules":failed,"rulebook_version":rule["version_id"]}

@app.post("/decide")
def decide_endpoint(body: DecideRequest):
    return create_decision(body.applicant_id, body.features)

@app.post("/api/applications/score")
def legacy_decide(body: dict[str, Any]):
    f = body["features"]
    feat = FeaturesIn(
        rent_months_ontime=float(f["rentRegularity"])*12,
        utility_months_ontime=float(f["utilityRegularity"])*12,
        telecom_months_ontime=float(f["telecomActivity"])*12,
        income_proxy=float(body.get("incomeProxy",0.5)),
        tenure_months=float(body.get("tenureMonths",24)),
        propertySqft=float(body.get("propertySqft",0)),
        audit_group=body.get("group"),
        assets=body.get("assets", ""),
        age=float(body.get("age",25)),
        kyc_status=body.get("kycStatus","verified"),
    )
    result=create_decision(body["ref"], feat)
    # Convert server representation for existing UI.
    if result["decision"] == "no_decision":
        raise HTTPException(500, result["reason"])
    return {"id": result["snapshot_id"], "ref": body["ref"], "group": body.get("group","Group A"), "features": f, "propertySqft": body.get("propertySqft",0), "assets": body.get("assets",""), "modelVersion": result["model_version"], "ruleVersion": 1, "score": result["score"], "decision": result["decision"].upper(), "reasons": result["top_4_reasons"], "timestamp": iso_now(), "snapshotHash": result["snapshot_id"]}

@app.get("/api/applications")
def applications_list(limit: int = Query(200, le=1000)):
    con=connect(); rows=con.execute("SELECT * FROM decision_snapshots ORDER BY created_at LIMIT ?", (limit,)).fetchall(); con.close()
    out=[]
    for idx,row in enumerate(rows, start=1):
        d=snapshot_to_dict(row); d["snapshot_id"]=d["id"]; d["id"]=idx; d["ref"]=d["applicant_id"]; d["group"]=d["input_payload"].get("audit_group") or "Unknown"; d["features"]={
            "rentRegularity": d["input_payload"]["scorer_features"]["rent_months_ontime"]/12,
            "utilityRegularity": d["input_payload"]["scorer_features"]["utility_months_ontime"]/12,
            "telecomActivity": d["input_payload"]["scorer_features"]["telecom_months_ontime"]/12,
            "propertySize": min(1.0,float(d["input_payload"].get("propertySqft",0))/3000),
        }
        d["propertySqft"]=d["input_payload"].get("propertySqft",0); d["assets"]=d["input_payload"].get("assets",""); d["modelVersion"]=d["model_version"]; d["ruleVersion"]=1; d["decision"]=d["decision"].upper(); d["timestamp"]=d["created_at"]; d["reasons"]=d["reasons"] or []
        out.append(d)
    return out


@app.get("/api/audit")
def audit_list():
    con=connect(); rows=con.execute("SELECT * FROM audit_log ORDER BY id").fetchall(); con.close()
    return [{"id":r["id"],"eventType":r["entry_type"],"applicationId":r["reference_id"],"ref":json.loads(r["payload_json"]).get("snapshot",{}).get("applicant_id") if r["entry_type"]=="decision" else None,"success":r["entry_type"]=="decision","prevHash":r["prev_hash"],"hash":r["entry_hash"],"timestamp":r["created_at"],"payload":json.loads(r["payload_json"])} for r in rows]

@app.get("/audit/verify")
def audit_verify():
    con=connect(); result=verify_chain(con); con.close(); return result

@app.get("/api/audit/verify")
def audit_verify_legacy():
    con=connect(); r=verify_chain(con); con.close(); return {"valid":r["valid"],"records":r["total_entries"],"badRecordIds":[] if r["valid"] else [r["break_at_entry_id"]],"genesis":"GENESIS"}

@app.post("/api/audit/tamper/{audit_id}")
def audit_tamper_legacy(audit_id:int):
    con=connect(); row=con.execute("SELECT * FROM audit_log WHERE id=?",(audit_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Audit entry not found")
    payload=json.loads(row["payload_json"]); payload["_demo_tamper"]=True
    # Bypass trigger only inside a scratch-like manual demonstration using PRAGMA? Triggers intentionally prevent production tampering.
    con.execute("DROP TRIGGER audit_log_no_update")
    con.execute("UPDATE audit_log SET payload_json=? WHERE id=?",(canonical(payload),audit_id))
    con.execute("CREATE TRIGGER audit_log_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT,'audit_log is append-only'); END;")
    con.commit(); con.close(); return {"ok":True}

@app.post("/api/audit/reset-tamper/{audit_id}")
def audit_reset_tamper(audit_id:int):
    con=connect(); row=con.execute("SELECT * FROM audit_log WHERE id=?",(audit_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Audit entry not found")
    payload=json.loads(row["payload_json"]); payload.pop("_demo_tamper",None)
    con.execute("DROP TRIGGER audit_log_no_update")
    con.execute("UPDATE audit_log SET payload_json=? WHERE id=?",(canonical(payload),audit_id))
    # Recompute entire chain to restore the original deterministic chain.
    rows=con.execute("SELECT * FROM audit_log ORDER BY id").fetchall(); prev="GENESIS"
    for r in rows:
        h=sha256_text(f"{r['id']}|{r['entry_type']}|{r['reference_id'] or ''}|{r['payload_json']}|{r['created_at']}|{prev}")
        con.execute("UPDATE audit_log SET prev_hash=?,entry_hash=? WHERE id=?",(prev,h,r["id"])); prev=h
    con.execute("CREATE TRIGGER audit_log_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT,'audit_log is append-only'); END;")
    con.commit(); con.close(); return {"ok":True}


def tamper_scratch(strategy: str) -> dict[str, Any]:
    # Copy the audit table into an in-memory database and demonstrate detection without touching the real log.
    con=connect(); rows=[dict(r) for r in con.execute("SELECT * FROM audit_log ORDER BY id").fetchall()]; con.close()
    if not rows: return {"valid_after_tamper": False, "break_at_entry_id": None, "strategy":strategy, "note":"no rows"}
    import copy
    scratch=copy.deepcopy(rows)
    if strategy=="edit": scratch[len(scratch)//2]["payload_json"] = canonical({"tampered":True})
    elif strategy=="delete": scratch.pop(len(scratch)//2)
    elif strategy=="reorder":
        i=max(0,len(scratch)//2-1); scratch[i],scratch[i+1]=scratch[i+1],scratch[i]
    prev="GENESIS"; bad=None
    for r in scratch:
        h=sha256_text(f"{r['id']}|{r['entry_type']}|{r['reference_id'] or ''}|{r['payload_json']}|{r['created_at']}|{r['prev_hash']}")
        if r["prev_hash"]!=prev or r["entry_hash"]!=h:
            bad=r["id"]; break
        prev=r["entry_hash"]
    return {"strategy":strategy,"valid_after_tamper":bad is None,"break_at_entry_id":bad}

@app.post("/audit/tamper-test/{strategy}")
def audit_tamper_test(strategy: str):
    if strategy not in {"edit","delete","reorder"}: raise HTTPException(400,"strategy must be edit, delete or reorder")
    return tamper_scratch(strategy)

@app.post("/replay/{snapshot_id}")
def replay_snapshot(snapshot_id: str):
    con=connect(); row=con.execute("SELECT * FROM decision_snapshots WHERE id=?",(snapshot_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Snapshot not found")
    snap=snapshot_to_dict(row); model=get_model_by_version(con,row["model_version"]); rule=get_rule_by_version(con,row["rulebook_version"]); con.close()
    inp=snap["input_payload"]; features=inp["scorer_features"]; kyc=inp["kyc_fields"]
    score,reasons=model_score(features,model); eligible,failed=evaluate_rules(rule,kyc); dec="approve" if eligible and score>=rule.get("threshold",0.6) else "decline"
    replayed={"score":score,"decision":dec,"reasons":reasons,"eligibility_result":eligible,"failed_rules":failed,"model_version":model["version_id"],"rulebook_version":rule["version_id"]}
    return {"original":snap,"replayed":replayed,"match":score==row["score"] and dec==row["decision"] and eligible==bool(row["eligibility_result"]) and reasons==snap["reasons"]}

@app.post("/api/replay")
def replay_legacy(body: ReplayRequest):
    con=connect()
    rows=con.execute("SELECT id FROM decision_snapshots ORDER BY created_at").fetchall()
    if body.applicationId is None or body.applicationId < 1 or body.applicationId > len(rows):
        con.close(); raise HTTPException(400,"Invalid application id")
    snap_id=rows[body.applicationId-1]["id"]
    row=con.execute("SELECT * FROM decision_snapshots WHERE id=?",(snap_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Snapshot not found")
    con.close()
    result=replay_snapshot(snap_id)
    return result


@app.get("/replay/all")
def replay_all():
    con=connect(); ids=[r["id"] for r in con.execute("SELECT id FROM decision_snapshots ORDER BY created_at").fetchall()]; con.close()
    mismatches=[]; matched=0
    for sid in ids:
        r=replay_snapshot(sid)
        if r["match"]: matched+=1
        else: mismatches.append(sid)
    return {"total":len(ids),"matched":matched,"pct_match":(100*matched/len(ids) if ids else 100.0),"mismatches":mismatches}

@app.get("/fairness/report")
def fairness_report():
    if not FAIRNESS_PATH.exists(): raise HTTPException(500,"Fairness test set unavailable")
    data=json.loads(FAIRNESS_PATH.read_text())
    con=connect(); model=get_model_by_version(con, con.execute("SELECT version_id FROM model_versions ORDER BY created_at LIMIT 1").fetchone()[0]); rule=get_active_rule(con); con.close()
    group_stats={}
    y_true=[]; y_pred=[]
    for r in data:
        feat={"rent_months_ontime":r["features"][0]*12,"utility_months_ontime":r["features"][1]*12,"telecom_months_ontime":r["features"][2]*12,"income_proxy":r["features"][3],"tenure_months":r["features"][4]*96}
        score,_=model_score(feat,model); pred=int(score>=rule.get("threshold",0.6)); g=str(r["group"])
        s=group_stats.setdefault(g,{"tp":0,"positive":0,"total":0,"approved":0}); s["total"]+=1; s["approved"]+=pred; s["positive"]+=r["repaid"]; s["tp"]+=pred and r["repaid"]
        y_true.append(r["repaid"]); y_pred.append(pred)
    out={}
    for g,s in group_stats.items(): out[g]={"total":s["total"],"approval_rate":s["approved"]/s["total"],"tpr":s["tp"]/s["positive"] if s["positive"] else None}
    tprs=[v["tpr"] for v in out.values() if v["tpr"] is not None]
    return {"group_tprs":out,"tpr_gap":max(tprs)-min(tprs) if tprs else None}

@app.get("/fairness/proxy-leakage")
def proxy_leakage():
    data=json.loads(FAIRNESS_PATH.read_text()); y=np.array([r["group"] for r in data])
    real=np.array([r["features"] for r in data]); proxies=np.array([[r["pincode_proxy"],r["surname_proxy"]] for r in data])
    clf1=LogisticRegression(max_iter=500).fit(real,y); clf2=LogisticRegression(max_iter=500).fit(proxies,y)
    return {"real_features_auc":float(roc_auc_score(y,clf1.predict_proba(real)[:,1])),"known_proxies_auc":float(roc_auc_score(y,clf2.predict_proba(proxies)[:,1]))}

@app.get("/api/fairness")
def fairness_legacy():
    f=fairness_report(); p=proxy_leakage(); con=connect(); rows=con.execute("SELECT id,input_payload_json,decision FROM decision_snapshots").fetchall(); con.close()
    groups={}
    for r in rows:
        inp=json.loads(r["input_payload_json"]); g=inp.get("audit_group") or "Unknown"; s=groups.setdefault(g,{"total":0,"approved":0}); s["total"]+=1; s["approved"]+=r["decision"]=="approve"
    for g,v in groups.items(): v["approvalRate"]=v["approved"]/v["total"] if v["total"] else 0
    rates=[v["approvalRate"] for v in groups.values()]
    return {"groups":groups,"approvalRateGap":max(rates)-min(rates) if rates else 0,"equalOpportunityTPRGap":f["tpr_gap"],"proxyCorrelations":{},"proxyAUC":p}

@app.post("/simulate-rule")
def simulate_rule(body: SimulateRequest):
    con=connect(); rows=con.execute("SELECT * FROM decision_snapshots ORDER BY created_at").fetchall(); out=[]
    for row in rows:
        inp=json.loads(row["input_payload_json"]); fields={**inp["kyc_fields"], **inp["scorer_features"]}
        condition_ok=eval_condition(body.condition,fields) if body.condition else True
        new_dec="approve" if condition_ok and row["score"] >= (body.threshold if body.threshold is not None else 0.6) else "decline"
        if new_dec!=row["decision"]: out.append({"snapshot_id":row["id"],"old_decision":row["decision"],"new_decision":new_dec})
    con.close(); return {"would_flip":out,"flip_count":len(out)}

@app.post("/api/rules/impact")
def simulate_legacy(body: LegacyRuleRequest):
    r=simulate_rule(SimulateRequest(condition={},threshold=body.threshold)); return {"affectedCount":r["flip_count"],"total":len(r["would_flip"]),"changes":r["would_flip"]}


def screen_name(name:str) -> tuple[bool,Optional[str],float]:
    normalized=unicodedata.normalize("NFKC",name).translate(HOMOGLYPHS).casefold().strip()
    con=connect(); entries=[r["name"] for r in con.execute("SELECT name FROM watchlist_entries")]; con.close()
    best_score=0.0; best=None
    for entry in entries:
        target=unicodedata.normalize("NFKC",entry).translate(HOMOGLYPHS).casefold().strip()
        score=float(fuzz.ratio(normalized,target))/100.0
        if score>best_score: best_score=score; best=entry
    return best_score>=0.90,best if best_score>=0.90 else None,best_score

@app.post("/watchlist/screen")
def watchlist_screen(body: WatchlistRequest):
    m,e,s=screen_name(body.name); return {"match":m,"matched_entry":e,"match_score":round(s,4)}

@app.get("/watchlist/evaluate")
def watchlist_eval():
    con=connect(); rows=con.execute("SELECT * FROM watchlist_test_set ORDER BY id").fetchall(); con.close()
    y=[]; p=[]
    for r in rows:
        m,_,_=screen_name(r["name_variant"]); y.append(r["is_positive"]); p.append(int(m))
    precision,recall,f1,_=precision_recall_fscore_support(y,p,average="binary",zero_division=0)
    return {"f1":float(f1),"precision":float(precision),"recall":float(recall)}

@app.post("/admin/ban-feature")
def ban_feature(body: BanFeatureRequest):
    if body.feature_name not in FEATURES: raise HTTPException(400,"Unknown Scorer feature")
    now=iso_now(); con=connect(); con.execute("INSERT OR REPLACE INTO feature_bans(feature_name,banned_at,reason) VALUES (?,?,?)",(body.feature_name,now,body.reason)); con.commit()
    before=con.execute("SELECT COUNT(*) FROM decision_snapshots WHERE created_at < ? AND input_payload_json LIKE ?",(now,f'%{body.feature_name}%')).fetchone()[0]
    after=con.execute("SELECT COUNT(*) FROM decision_snapshots WHERE created_at >= ? AND input_payload_json LIKE ?",(now,f'%{body.feature_name}%')).fetchone()[0]
    con.close(); return {"banned_at":now,"decisions_before_ban_using_feature":before,"decisions_after_ban_using_feature":after}

@app.post("/api/demo/seed")
def seed_demo():
    con=connect();
    # Do not mutate snapshots directly. For demo reset, create a fresh DB file externally via the script; this endpoint only seeds additional data.
    con.close(); return {"ok":True,"note":"Use scripts/seed_demo.py for a clean deterministic reset because decision_snapshots and audit_log are immutable/append-only."}

@app.post("/helpdesk")
def helpdesk(body: HelpdeskRequest):
    q=body.message.lower().strip(); context="The register scores alternate-data features using a pinned logistic model and a versioned rulebook."
    if body.applicantRef:
        con=connect(); row=con.execute("SELECT * FROM decision_snapshots WHERE applicant_id=? ORDER BY created_at DESC LIMIT 1",(body.applicantRef,)).fetchone(); con.close()
        if row: context=f"Applicant {body.applicantRef}: decision {row['decision']}, score {row['score']:.3f}, model {row['model_version']}, rulebook {row['rulebook_version']}."
    if "why" in q or "decline" in q: reply=f"{context} The decision is the deterministic result of the stored score, the pinned rulebook threshold, and eligibility rules. The top signed model contributions are stored with the snapshot."
    elif "replay" in q: reply=f"{context} Replay loads the exact model_version and rulebook_version recorded on that snapshot rather than resolving current versions."
    elif "audit" in q or "hash" in q: reply="The audit chain starts at GENESIS and each entry hashes its own content plus the previous entry hash. Verification catches edits, deletes, and reordering."
    elif "fair" in q: reply="Fairness is evaluated with equal opportunity as the target criterion: we report group TPRs on a held-out synthetic set and separately test known-proxy leakage."
    else: reply=context
    return {"reply":reply}

@app.get("/system/health")
def system_health():
    con=connect(); lat=[int(r[0]) for r in con.execute("SELECT latency_ms FROM decision_snapshots ORDER BY created_at DESC LIMIT 200").fetchall()]; con.close()
    def pct(p):
        if not lat: return None
        arr=sorted(lat); return int(arr[min(len(arr)-1,max(0,int(math.ceil(p*len(arr)))-1))])
    rep=replay_all(); watch=watchlist_eval(); aud=audit_verify()
    p95=pct(.95)
    return {"latency_p50":pct(.5),"latency_p95":p95,"replay_pct_match":rep["pct_match"],"watchlist_f1":watch["f1"],"audit_integrity":aud["valid"],"budgets":{"decision_latency_pass": p95 is None or p95 < 90000,"reproducibility_pass":rep["pct_match"]==100.0,"watchlist_pass":watch["f1"]>=0.8,"audit_pass":aud["valid"]}}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app:app", host="0.0.0.0", port=8000, reload=False)
