from pathlib import Path
import sys, subprocess, json
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.app import connect, FeaturesIn, create_decision
# Demonstration helper: ban a feature, then attempt a post-ban decision.
con=connect(); con.execute('DELETE FROM feature_bans'); con.commit(); con.close()
pre=create_decision('APP-2001', FeaturesIn(rent_months_ontime=11,utility_months_ontime=10,telecom_months_ontime=11,income_proxy=.7,tenure_months=36,age=24,kyc_status='verified'))
con=connect(); import backend.app as m
res=m.ban_feature(m.BanFeatureRequest(feature_name='income_proxy',reason='H+8 retroactive feature ban drill'))
con.close()
post=create_decision('APP-2001', FeaturesIn(rent_months_ontime=11,utility_months_ontime=10,telecom_months_ontime=11,income_proxy=.7,tenure_months=36,age=24,kyc_status='verified'))
print(json.dumps({'before':pre,'ban':res,'after':post},indent=2))
