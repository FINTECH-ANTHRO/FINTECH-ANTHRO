from backend.app import setup
from pathlib import Path
print('Model and database initialized:', Path('models/model_artifact.json').resolve())
