from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.app import connect, init_schema, ensure_seed, create_decision, FeaturesIn

DB = Path(__file__).resolve().parents[1] / 'data' / 'fs2602.db'
if DB.exists(): DB.unlink()
for ext in ['-wal','-shm']:
    p=Path(str(DB)+ext)
    if p.exists(): p.unlink()
con=connect(); init_schema(con); ensure_seed(con)
rows=[
('APP-2001','Ananya Rao','Group A',11,10,11,0.72,38,1800,True),
('APP-2002','Rohit Sharma','Group B',11,10,11,0.70,36,1750,True),
('APP-2003','Priya Iyer','Group A',10,11,10,0.66,48,2400,True),
('APP-2004','Arjun Patel','Group B',10,10,10,0.62,42,2300,True),
('APP-2005','Meera Nair','Group A',6,6,7,0.28,14,700,False),
('APP-2006','Karthik Reddy','Group B',5,6,7,0.25,11,700,False),
]
now='2026-09-12T00:00:00Z'
for ref,name,group,r,u,t,inc,ten,sqft,repaid in rows:
    con.execute('INSERT INTO applicants(applicant_id,name,email,phone,dob,id_type,id_number,address,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',(ref,name,name.replace(' ','').lower()+'@demo.example','+91 90000 00000','1999-01-01','PAN','DEMO-'+ref[-4:],'Demo City',now,now))
con.close()
for ref,name,group,r,u,t,inc,ten,sqft,repaid in rows:
    out=create_decision(ref, FeaturesIn(rent_months_ontime=r,utility_months_ontime=u,telecom_months_ontime=t,income_proxy=inc,tenure_months=ten,propertySqft=sqft,audit_group=group,assets='Demo context only',age=24,kyc_status='verified'))
    con=connect()
    if out.get('snapshot_id'):
        con.execute('INSERT INTO outcomes(snapshot_id,repaid) VALUES (?,?)',(out['snapshot_id'],int(repaid))); con.commit()
    con.close()
print(json.dumps({'seeded':len(rows)}))
