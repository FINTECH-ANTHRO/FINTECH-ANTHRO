import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.app import tamper_scratch
for strategy in ['edit','delete','reorder']:
    print(strategy, tamper_scratch(strategy))
