from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.app import connect, FeaturesIn, create_decision

con=connect()
count=con.execute('SELECT COUNT(*) FROM decision_snapshots').fetchone()[0]
if count==0:
    now='2026-09-12T00:00:00Z'
    demo=[
        ('APP-2001','Ananya Rao','Group A',11,10,11,0.72,38,1800),
        ('APP-2002','Rohit Sharma','Group B',11,10,11,0.70,36,1750),
        ('APP-2003','Priya Iyer','Group A',10,11,10,0.66,48,2400),
        ('APP-2004','Arjun Patel','Group B',10,10,10,0.62,42,2300),
        ('APP-2005','Meera Nair','Group A',6,6,7,0.28,14,700),
        ('APP-2006','Karthik Reddy','Group B',5,6,7,0.25,11,700),
    ]
    for ref,name,group,r,u,t,inc,ten,sqft in demo:
        con.execute('INSERT OR IGNORE INTO applicants(applicant_id,name,email,phone,dob,id_type,id_number,address,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',(ref,name,name.replace(' ','').lower()+'@demo.example','+91 90000 00000','1999-01-01','PAN','DEMO-'+ref[-4:],'Demo City',now,now))
    con.commit(); con.close()
    for ref,name,group,r,u,t,inc,ten,sqft in demo:
        create_decision(ref,FeaturesIn(rent_months_ontime=r,utility_months_ontime=u,telecom_months_ontime=t,income_proxy=inc,tenure_months=ten,propertySqft=sqft,audit_group=group,assets='Demo context only',age=24,kyc_status='verified'))
    print('Seeded demo dataset.')
else:
    con.close(); print('Existing decision snapshots found; leaving database untouched.')
