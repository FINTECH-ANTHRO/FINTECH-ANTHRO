(function(){
  "use strict";
  const API = "/api";
  const FEATURE_LABELS = {
    rentRegularity:"Rent payment history",
    utilityRegularity:"Utility bill payments",
    telecomActivity:"Telecom account activity",
    propertySize:"Property / home size"
  };
  const PROPERTY_SQFT_CAP = 3000;
  let profiles = [];
  let applications = [];
  let rules = [];
  let auditLog = [];
  let currentProfileRef = null;
  let helpdeskMessages = [];

  async function api(path, options={}){
    const res = await fetch(API + path, {
      headers:{"Content-Type":"application/json", ...(options.headers||{})},
      ...options
    });
    const data = await res.json().catch(()=>({detail:"Invalid server response"}));
    if(!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
    return data;
  }
  const esc = s => { const d=document.createElement("div"); d.textContent=s??""; return d.innerHTML; };
  const profileByRef = ref => profiles.find(p=>p.ref===ref);
  const appById = id => applications.find(a=>a.id===Number(id));
  const ruleByVersion = v => rules.find(r=>r.version===Number(v));
  const maskId = raw => { const c=(raw||"").replace(/\s+/g,""); return c.length<=4 ? (raw||"—") : "•••• •••• " + c.slice(-4); };

  async function refresh(){
    [profiles, applications, rules, auditLog] = await Promise.all([
      api("/profiles"), api("/applications"), api("/rules"), api("/audit")
    ]);
    refreshHeaderStats();
    renderProfilePanel(); populateApplyRefSelector(); renderDecisionPanel();
    renderRulebookPanel(); renderAuditPanel(); populateReplaySelectors();
    populateHelpdeskApplicantSelector();
  }

  function refreshHeaderStats(){
    document.getElementById("statProfiles").textContent=profiles.length;
    document.getElementById("statCount").textContent=applications.length;
    const latest=rules[rules.length-1];
    document.getElementById("statRule").textContent=latest?"v"+latest.version:"—";
  }

  const titles={
    profile:["Profile","Identity and contact details for an applicant, kept separate from the scoring signals in Apply."],
    apply:["Apply","Enter alternate-data signals for a thin-file applicant. Nothing here touches a credit bureau."],
    decision:["Decision","The stamp for the most recent application, and every decision on file."],
    rulebook:["Rulebook","Versioned, effective-dated rules — publish a change without a deployment."],
    audit:["Audit trail","A hash-chained record of every decision. Tamper with one entry and the chain shows it."],
    replay:["Replay","Re-run a past decision against the rulebook that produced it, or a different one."],
    fairness:["Fairness","Approval-rate parity, equal-opportunity TPR when outcomes exist, and proxy diagnostics."],
    helpdesk:["Helpdesk","Chat with an assistant about a specific decision, your data on file, or how the register works."]
  };
  async function showStage(stage){
    document.querySelectorAll(".stage-panel").forEach(p=>p.classList.remove("active"));
    document.getElementById("panel-"+stage).classList.add("active");
    document.querySelectorAll(".stage-btn").forEach(b=>{
      const active=b.dataset.stage===stage; b.classList.toggle("active",active);
      active?b.setAttribute("aria-current","page"):b.removeAttribute("aria-current");
    });
    document.getElementById("pageTitle").textContent=titles[stage][0];
    document.getElementById("pageSub").textContent=titles[stage][1];
    document.getElementById("pageTitle").classList.toggle("title-emph",["profile","apply","decision"].includes(stage));
    if(stage==="profile") renderProfilePanel();
    if(stage==="apply") populateApplyRefSelector();
    if(stage==="decision") renderDecisionPanel();
    if(stage==="rulebook") renderRulebookPanel();
    if(stage==="audit") renderAuditPanel();
    if(stage==="replay") { populateReplaySelectors(); document.getElementById("replayResult").innerHTML=""; }
    if(stage==="fairness") await renderFairnessPanel();
    if(stage==="helpdesk") renderHelpdeskPanel();
  }
  document.getElementById("stageNav").addEventListener("click",e=>{const b=e.target.closest(".stage-btn");if(b)showStage(b.dataset.stage);});

  function renderProfilePanel(){
    const wrap=document.getElementById("profileTableWrap");
    if(!profiles.length){wrap.innerHTML='<p class="empty">No applicant profiles on file yet.</p>';return;}
    wrap.innerHTML=`<table><thead><tr><th>Applicant ID</th><th>Name</th><th>Email</th><th>Phone</th><th>ID type</th><th>ID number</th></tr></thead><tbody>${profiles.map(p=>`<tr class="row-link" data-ref="${esc(p.ref)}"><td>${esc(p.ref)}</td><td>${esc(p.name||"—")}</td><td>${esc(p.email||"—")}</td><td>${esc(p.phone||"—")}</td><td><span class="id-chip">${esc(p.idType||"—")}</span></td><td class="hash">${esc(maskId(p.idNumber))}</td></tr>`).join("")}</tbody></table>`;
    wrap.querySelectorAll("tr.row-link").forEach(tr=>tr.addEventListener("click",()=>loadProfileIntoForm(tr.dataset.ref)));
  }
  function loadProfileIntoForm(ref){
    const p=profileByRef(ref); if(!p)return;
    currentProfileRef=ref;
    ["pName","pEmail","pPhone","pDob","pIdNumber","pAddress"].forEach((id,i)=>{});
    document.getElementById("pName").value=p.name||""; document.getElementById("pEmail").value=p.email||""; document.getElementById("pPhone").value=p.phone||""; document.getElementById("pDob").value=p.dob||""; document.getElementById("pIdType").value=p.idType||"Aadhaar"; document.getElementById("pIdNumber").value=p.idNumber||""; document.getElementById("pAddress").value=p.address||"";
    updateProfileRefDisplay(ref);
    document.getElementById("profileSaveMsg").innerHTML=`<div class="banner info">Loaded ${esc(ref)} into the form. Saving now will update this profile.</div>`;
  }
  function updateProfileRefDisplay(ref){document.getElementById("pRefDisplay").textContent=ref?ref+" — editing this profile":"Assigned automatically when you save";}
  document.getElementById("btnSaveProfile").addEventListener("click",async()=>{
    const msg=document.getElementById("profileSaveMsg");
    const btn=document.getElementById("btnSaveProfile"); btn.disabled=true;
    try{
      const data=await api("/profiles",{method:"POST",body:JSON.stringify({ref:currentProfileRef,name:document.getElementById("pName").value.trim(),email:document.getElementById("pEmail").value.trim(),phone:document.getElementById("pPhone").value.trim(),dob:document.getElementById("pDob").value,idType:document.getElementById("pIdType").value,idNumber:document.getElementById("pIdNumber").value.trim(),address:document.getElementById("pAddress").value.trim()})});
      currentProfileRef=data.ref; updateProfileRefDisplay(data.ref); msg.innerHTML=`<div class="banner ok">Profile saved to the backend. Applicant ID: <b>${esc(data.ref)}</b>.</div>`; await refresh();
    }catch(e){msg.innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;} finally{btn.disabled=false;}
  });
  document.getElementById("btnClearProfileForm").addEventListener("click",()=>{["pName","pEmail","pPhone","pDob","pIdNumber","pAddress"].forEach(id=>document.getElementById(id).value="");document.getElementById("pIdType").value="Aadhaar";currentProfileRef=null;updateProfileRefDisplay(null);document.getElementById("profileSaveMsg").innerHTML="";});

  document.getElementById("btnLookup").addEventListener("click",async()=>{
    const ref=document.getElementById("lookupRef").value.trim(), box=document.getElementById("lookupResult");
    if(!ref){box.innerHTML='<div class="banner bad">Enter an applicant ID to look up.</div>';return;}
    try{
      const p=await api("/profiles/"+encodeURIComponent(ref)); const apps=applications.filter(a=>a.ref===ref);
      let html=`<div class="banner ok">Profile found for ${esc(ref)} — data retrieved from the backend database.</div><table><tbody><tr><th>Name</th><td>${esc(p.name||"—")}</td></tr><tr><th>Email</th><td>${esc(p.email||"—")}</td></tr><tr><th>Phone</th><td>${esc(p.phone||"—")}</td></tr><tr><th>Address</th><td>${esc(p.address||"—")}</td></tr></tbody></table>`;
      html+=apps.length?`<h3 style="margin-top:18px;">Applications on file</h3><table><thead><tr><th>Date</th><th>Score</th><th>Decision</th><th>Rule</th><th>Model</th></tr></thead><tbody>${apps.map(a=>`<tr><td>${esc(a.timestamp)}</td><td>${a.score.toFixed(3)}</td><td><span class="pill ${a.decision==='APPROVE'?'approve':'decline'}">${a.decision}</span></td><td>v${a.ruleVersion}</td><td>${esc(a.modelVersion)}</td></tr>`).join("")}</tbody></table>`:'<p class="empty">No applications on file for this ID yet.</p>';
      html+=`<div class="btn-row"><button class="secondary" id="btnLookupEdit">Load into form for editing</button></div>`; box.innerHTML=html; document.getElementById("btnLookupEdit").onclick=()=>loadProfileIntoForm(ref);
    }catch(e){box.innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}
  });

  function populateApplyRefSelector(){const sel=document.getElementById("inRef"),cur=sel.value;sel.innerHTML=profiles.length?['<option value="">Select an applicant ID…</option>'].concat(profiles.map(p=>`<option value="${esc(p.ref)}">${esc(p.ref)}${p.name?' — '+esc(p.name):''}</option>`)).join(""):'<option value="">No profiles yet — create one in Profile first</option>';if([...sel.options].some(o=>o.value===cur))sel.value=cur;}
  function readApplyForm(){const sqft=Math.max(0,Math.min(5000,parseInt(document.getElementById("in-property").value,10)||0));return{ref:document.getElementById("inRef").value,group:document.getElementById("inGroup").value,propertySqft:sqft,assets:document.getElementById("in-assets").value.trim(),features:{rentRegularity:+document.getElementById("in-rent").value/12,utilityRegularity:+document.getElementById("in-util").value/12,telecomActivity:+document.getElementById("in-tel").value/12,propertySize:Math.min(1,sqft/PROPERTY_SQFT_CAP)},incomeProxy:Math.max(0,Math.min(1,+document.getElementById("in-income").value||0.5)),tenureMonths:Math.max(0,Math.min(96,+document.getElementById("in-tenure").value||24)),age:Math.max(0,Math.min(120,+document.getElementById("in-age").value||24)),kycStatus:document.getElementById("in-kyc").value};}
  function refreshMeters(){[["in-rent","bar-rent","v-rent"],["in-util","bar-util","v-util"],["in-tel","bar-tel","v-tel"]].forEach(([a,b,c])=>{const v=Math.max(0,Math.min(12,parseInt(document.getElementById(a).value,10)||0));document.getElementById(a).value=v;document.getElementById(b).style.width=(v/12*100)+"%";document.getElementById(c).textContent=Math.round(v/12*100)+"% · "+v+" of 12 months";});const s=Math.max(0,Math.min(5000,parseInt(document.getElementById("in-property").value,10)||0));document.getElementById("in-property").value=s;document.getElementById("bar-property").style.width=Math.min(1,s/PROPERTY_SQFT_CAP)*100+"%";document.getElementById("v-property").textContent=s+" sq ft";}
  ["in-rent","in-util","in-tel","in-property"].forEach(id=>["input","blur"].forEach(ev=>document.getElementById(id).addEventListener(ev,refreshMeters))); refreshMeters();
  document.getElementById("btnScore").addEventListener("click",async()=>{const validation=document.getElementById("applyValidation"),btn=document.getElementById("btnScore"),app=readApplyForm();if(!app.ref){validation.innerHTML='<div class="banner bad">Select an applicant ID before scoring.</div>';return;}btn.disabled=true;validation.innerHTML="";try{await api("/applications/score",{method:"POST",body:JSON.stringify(app)});await refresh();await showStage("decision");}catch(e){validation.innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}finally{btn.disabled=false;}});
  document.getElementById("btnSample").addEventListener("click",async()=>{const b=document.getElementById("btnSample");b.disabled=true;try{await api("/demo/seed",{method:"POST"});await refresh();await showStage("decision");}catch(e){document.getElementById("applyValidation").innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}finally{b.disabled=false;}});

  function renderDecisionPanel(){const wrap=document.getElementById("decisionBody");if(!applications.length){wrap.innerHTML='<p class="empty">No application scored yet. Go to Apply.</p>';renderAppsTable();return;}const a=applications[applications.length-1],p=profileByRef(a.ref),r=ruleByVersion(a.ruleVersion);const cls=a.decision==="APPROVE"?"approve":"decline";const reasons=a.decision==="DECLINE"?`<h3 style="margin-top:22px;">Reasons for this decision</h3><ul class="reason-list">${a.reasons.map(x=>`<li><span>${esc(x.label)}</span><span class="weight">shortfall ${x.shortfall.toFixed(3)}</span></li>`).join("")}</ul>`:"";wrap.innerHTML=`<div class="stamp-wrap"><div class="stamp ${cls}">${a.decision}</div><div class="stamp-meta"><div><b>${esc(a.ref)}</b> — audit group ${esc(a.group)}</div>${p?`<div>Applicant <b>${esc(p.name)}</b> · ${esc(p.email||"")}</div>`:""}<div>Score <b>${a.score.toFixed(3)}</b> against threshold <b>${r.threshold.toFixed(2)}</b></div><div>Model <b>${esc(a.modelVersion)}</b> · rulebook <b>v${a.ruleVersion}</b></div><div>Decision snapshot <b>${esc(a.snapshotHash.slice(0,20))}…</b></div></div></div>${reasons}`;renderAppsTable();}
  function renderAppsTable(){const wrap=document.getElementById("appsTableWrap");if(!applications.length){wrap.innerHTML='<p class="empty">Nothing on file yet.</p>';return;}wrap.innerHTML=`<table><thead><tr><th>Applicant ID</th><th>Group</th><th>Score</th><th>Decision</th><th>Rule</th><th>Model</th><th>Date</th></tr></thead><tbody>${applications.slice().reverse().map(a=>`<tr class="row-link" data-appid="${a.id}"><td>${esc(a.ref)}</td><td>${esc(a.group)}</td><td>${a.score.toFixed(3)}</td><td><span class="pill ${a.decision==='APPROVE'?'approve':'decline'}">${a.decision}</span></td><td>v${a.ruleVersion}</td><td>${esc(a.modelVersion)}</td><td>${esc(a.timestamp)}</td></tr>`).join("")}</tbody></table>`;wrap.querySelectorAll("tr.row-link").forEach(tr=>tr.onclick=()=>{showStage("replay");populateReplaySelectors();document.getElementById("replayApp").value=tr.dataset.appid;});}

  const wMap={"w-rent":"rentRegularity","w-util":"utilityRegularity","w-tel":"telecomActivity","w-property":"propertySize"};
  function checkWeightSum(){const total=Object.keys(wMap).reduce((s,id)=>s+ +document.getElementById(id).value/100,0);document.getElementById("ruleWeightWarn").innerHTML=Math.abs(total-1)>.03?`<div class="banner info">Weights sum to ${total.toFixed(2)}, not 1.00. Publish is allowed, but scores may drift.</div>`:"";}
  Object.keys(wMap).forEach(id=>document.getElementById(id).addEventListener("input",()=>{document.getElementById({"w-rent":"v-w-rent","w-util":"v-w-util","w-tel":"v-w-tel","w-property":"v-w-property"}[id]).textContent=(+document.getElementById(id).value/100).toFixed(2);checkWeightSum();}));
  document.getElementById("ruleThresh").addEventListener("input",e=>document.getElementById("v-thresh").textContent=(+e.target.value/100).toFixed(2));
  function renderRulebookPanel(){document.getElementById("rulebookTableWrap").innerHTML=`<table><thead><tr><th>Version</th><th>Effective</th><th>Threshold</th><th>Weights</th><th>Note</th></tr></thead><tbody>${rules.map(r=>`<tr><td>v${r.version}</td><td>${esc(r.effectiveDate)}</td><td>${r.threshold.toFixed(2)}</td><td>${Object.entries(r.weights).map(([k,v])=>FEATURE_LABELS[k].split(" ")[0]+" "+v.toFixed(2)).join(" · ")}</td><td>${esc(r.note)}</td></tr>`).join("")}</tbody></table>`;}
  document.getElementById("btnPublishRule").addEventListener("click",async()=>{const btn=document.getElementById("btnPublishRule");btn.disabled=true;try{const body={effectiveDate:document.getElementById("ruleDate").value||new Date().toISOString().slice(0,10),weights:{rentRegularity:+document.getElementById("w-rent").value/100,utilityRegularity:+document.getElementById("w-util").value/100,telecomActivity:+document.getElementById("w-tel").value/100,propertySize:+document.getElementById("w-property").value/100},threshold:+document.getElementById("ruleThresh").value/100,note:document.getElementById("ruleNote").value.trim()||"No note provided."};const impact=await api("/rules/impact",{method:"POST",body:JSON.stringify(body)});await api("/rules",{method:"POST",body:JSON.stringify(body)});await refresh();document.getElementById("ruleWeightWarn").innerHTML=`<div class="banner ok">Published new rulebook version. Impact simulator predicted <b>${impact.affectedCount}</b> of ${impact.total} stored decisions would flip under the proposed policy.</div>`;}catch(e){document.getElementById("ruleWeightWarn").innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}finally{btn.disabled=false;}});

  function renderAuditPanel(){const wrap=document.getElementById("auditTableWrap");if(!auditLog.length){wrap.innerHTML='<p class="empty">No decisions logged yet.</p>';return;}wrap.innerHTML=`<table><thead><tr><th>#</th><th>Event</th><th>Applicant</th><th>Decision</th><th>Prev. hash</th><th>Record hash</th></tr></thead><tbody>${auditLog.map(r=>`<tr><td>#${r.id}</td><td>${esc(r.eventType)}</td><td>${esc(r.ref||"—")}</td><td>${r.payload?.decision?`<span class="pill ${r.payload.decision==='APPROVE'?'approve':'decline'}">${r.payload.decision}</span>`:"—"}</td><td class="hash">${r.prevHash.slice(0,12)}…</td><td class="hash">${r.hash.slice(0,12)}…</td></tr>`).join("")}</tbody></table>`;}
  document.getElementById("btnVerify").addEventListener("click",async()=>{try{const r=await api("/audit/verify");document.getElementById("verifyResult").innerHTML=r.valid?`<div class="banner ok">Chain verified. All <b>${r.records}</b> records match from the genesis hash.</div>`:`<div class="banner bad">Chain broken. Invalid records: ${r.badRecordIds.join(", ")}.</div>`;}catch(e){document.getElementById("verifyResult").innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}});
  document.getElementById("btnTamper").addEventListener("click",async()=>{try{await api("/audit/tamper/1",{method:"POST"});await refresh();document.getElementById("verifyResult").innerHTML='<div class="banner info">Demo tamper applied to record #1 without changing its stored hash. Verify the chain to catch it.</div>';}catch(e){document.getElementById("verifyResult").innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}});
  document.getElementById("btnResetTamper").addEventListener("click",async()=>{try{await api("/audit/reset-tamper/1",{method:"POST"});await refresh();document.getElementById("verifyResult").innerHTML='<div class="banner ok">Demo tamper removed. The original chain is restored.</div>';}catch(e){document.getElementById("verifyResult").innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}});

  function populateReplaySelectors(){const a=document.getElementById("replayApp"),r=document.getElementById("replayRule"),ac=a.value,rc=r.value;a.innerHTML=applications.map(x=>`<option value="${x.id}">${esc(x.ref)} (scored under v${x.ruleVersion})</option>`).join("");r.innerHTML=rules.map(x=>`<option value="${x.version}">v${x.version} — effective ${esc(x.effectiveDate)}</option>`).join("");if([...a.options].some(o=>o.value===ac))a.value=ac;if([...r.options].some(o=>o.value===rc))r.value=rc;}
  document.getElementById("btnReplay").addEventListener("click",async()=>{const box=document.getElementById("replayResult");try{const r=await api("/replay",{method:"POST",body:JSON.stringify({applicationId:+document.getElementById("replayApp").value,ruleVersion:+document.getElementById("replayRule").value})});box.innerHTML=r.match?`<div class="banner ok">Match. Server replay reproduced score <b>${r.replayed.score.toFixed(3)}</b> and decision <b>${r.replayed.decision}</b> using model ${esc(r.replayed.modelVersion)} and rule v${r.replayed.ruleVersion}.</div>`:`<div class="banner info">Replay under rule v${r.replayed.ruleVersion} produced <b>${r.replayed.score.toFixed(3)} / ${r.replayed.decision}</b>. Original was ${r.original.score.toFixed(3)} / ${r.original.decision} under v${r.original.ruleVersion}. This is a policy impact comparison, not the reproducibility check.</div>`;}catch(e){box.innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}});

  async function renderFairnessPanel(){try{const f=await api("/fairness");const groups=f.groups;document.getElementById("fairnessBars").innerHTML=Object.entries(groups).length?Object.entries(groups).map(([g,v])=>`<div class="fair-bar-row"><div class="g-label">${esc(g)}</div><div class="fair-bar-track"><div class="fair-bar-fill" style="width:${Math.round(v.approvalRate*100)}%"></div></div><div class="g-val">${Math.round(v.approvalRate*100)}%</div></div>`).join("")+`<div class="banner info" style="margin-top:18px;">Approval-rate gap: <b>${(f.approvalRateGap*100).toFixed(1)} pp</b>${f.equalOpportunityTPRGap==null?" · No labelled repayment outcomes yet, so TPR gap is not estimated.":` · Equal-opportunity TPR gap: <b>${(f.equalOpportunityTPRGap*100).toFixed(1)} pp</b>`}</div>`:'<p class="empty">Score some applications first.</p>';const corr=f.proxyCorrelations||{};document.getElementById("proxyTableWrap").innerHTML=Object.keys(corr).length?`<table><thead><tr><th>Feature</th><th>Correlation with group</th><th>Flag</th></tr></thead><tbody>${Object.entries(corr).map(([k,v])=>`<tr><td>${FEATURE_LABELS[k]}</td><td>${v.toFixed(2)}</td><td>${Math.abs(v)>.3?'<span class="pill decline">check for proxy</span>':'<span class="pill approve">low</span>'}</td></tr>`).join("")}</tbody></table>`:'<p class="empty">Score some applications first.</p>';}catch(e){document.getElementById("fairnessBars").innerHTML=`<div class="banner bad">${esc(e.message)}</div>`;}}

  function populateHelpdeskApplicantSelector(){const sel=document.getElementById("helpdeskApplicant"),cur=sel.value;sel.innerHTML=['<option value="">General question — no applicant selected</option>'].concat(applications.map(a=>`<option value="${esc(a.ref)}">${esc(a.ref)} — ${a.decision}</option>`)).join("");if([...sel.options].some(o=>o.value===cur))sel.value=cur;}
  function renderChatLog(){const log=document.getElementById("chatLog");if(!helpdeskMessages.length){log.innerHTML='<p class="empty">Ask anything about a decision, the scoring signals, or how to read this register.</p>';return;}log.innerHTML=helpdeskMessages.map(m=>`<div class="chat-bubble ${m.role==='user'?'user':'assistant'}">${esc(m.content)}</div>`).join("");log.scrollTop=log.scrollHeight;}
  async function sendChatMessage(text){text=(text||"").trim();if(!text)return;helpdeskMessages.push({role:"user",content:text});renderChatLog();document.getElementById("chatInput").value="";document.getElementById("chatTyping").style.display="block";document.getElementById("btnChatSend").disabled=true;try{const r=await api("/helpdesk",{method:"POST",body:JSON.stringify({message:text,applicantRef:document.getElementById("helpdeskApplicant").value||null})});helpdeskMessages.push({role:"assistant",content:r.reply});}catch(e){helpdeskMessages.push({role:"assistant",content:"Backend helpdesk error: "+e.message});}finally{document.getElementById("chatTyping").style.display="none";document.getElementById("btnChatSend").disabled=false;renderChatLog();}}
  function renderHelpdeskPanel(){populateHelpdeskApplicantSelector();renderChatLog();}
  document.getElementById("btnChatSend").addEventListener("click",()=>sendChatMessage(document.getElementById("chatInput").value));
  document.getElementById("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChatMessage(document.getElementById("chatInput").value);}});
  document.querySelectorAll(".chat-quick").forEach(b=>b.addEventListener("click",()=>sendChatMessage(b.dataset.prompt)));

  // Google remains a clearly labelled demo identity picker; the resulting profile is persisted server-side.
  const GOOGLE_DEMO_ACCOUNTS=[{name:"Ananya Rao",email:"ananya.rao82@gmail.com",phone:"+91 98450 11223"},{name:"Rohit Sharma",email:"rohit.sharma.dev@gmail.com",phone:"+91 90210 44556"},{name:"Priya Iyer",email:"priya.iyer.19@gmail.com",phone:"+91 87654 99001"}];
  document.getElementById("btnGoogleConnect").addEventListener("click",()=>{const wrap=document.getElementById("googleAccountList");wrap.innerHTML=GOOGLE_DEMO_ACCOUNTS.map((a,i)=>`<button type="button" class="google-account-item" data-idx="${i}"><span class="google-avatar">${a.name[0]}</span><span><span class="google-acc-name">${esc(a.name)}</span><span class="google-acc-email">${esc(a.email)}</span></span></button>`).join("");wrap.querySelectorAll("button").forEach(b=>b.onclick=()=>{const a=GOOGLE_DEMO_ACCOUNTS[+b.dataset.idx];document.getElementById("pName").value=a.name;document.getElementById("pEmail").value=a.email;document.getElementById("pPhone").value=a.phone;document.getElementById("googleModalOverlay").style.display="none";document.getElementById("googleAuthStatus").innerHTML='<div class="banner info">Demo Google profile selected. Review and save to persist it through the backend.</div>';});document.getElementById("googleModalOverlay").style.display="flex";});
  document.getElementById("googleModalClose").addEventListener("click",()=>document.getElementById("googleModalOverlay").style.display="none");
  document.getElementById("googleModalOverlay").addEventListener("click",e=>{if(e.target.id==="googleModalOverlay")document.getElementById("googleModalOverlay").style.display="none";});
  document.getElementById("btnGoogleDisconnect").addEventListener("click",()=>{document.getElementById("googleAuthStatus").innerHTML="";document.getElementById("btnGoogleConnect").style.display="inline-flex";document.getElementById("btnGoogleDisconnect").style.display="none";});

  document.getElementById("btnWelcomeBegin").addEventListener("click",()=>{document.getElementById("welcomePage").style.display="none";document.getElementById("appShell").style.display="flex";showStage("profile");});
  function applyTheme(theme){document.documentElement.setAttribute("data-theme",theme);try{localStorage.setItem("fs2602-theme",theme);}catch(e){}const btn=document.getElementById("themeToggle");const label=theme==="dark"?"Switch to light mode":"Switch to dark mode";btn.setAttribute("aria-label",label);btn.setAttribute("title",label);}
  document.getElementById("themeToggle").addEventListener("click",()=>{const cur=document.documentElement.getAttribute("data-theme")==="dark"?"dark":"light";applyTheme(cur==="dark"?"light":"dark");});
  applyTheme(document.documentElement.getAttribute("data-theme")==="dark"?"dark":"light");

  (async()=>{try{await api("/health");await refresh();}catch(e){document.getElementById("welcomePage").querySelector(".welcome-foot").innerHTML='<b>Backend unavailable.</b> Start the FastAPI server and reload this page.';console.error(e);}})();
})();
